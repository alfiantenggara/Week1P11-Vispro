import 'dart:io';
import 'dart:core';
import 'dart:math';

void main() {
  print("Masukkan angka: ");
  int? n = int.parse(stdin.readLineSync()!);

  List<int> numbers = List.generate(n, (_) => Random().nextInt(100));

  print("Angka yang di-generate: $numbers");

  print("Pilih metode: ");
  print("1. Bubble Sort");
  print("2. Inversi");
  print("3. Shuffle");
  int? pilihan = int.parse(stdin.readLineSync()!);

  Stopwatch stopwatch = Stopwatch();
  stopwatch.start();

  if (pilihan == 1 || pilihan == 2 || pilihan == 3) {
    performOperation(numbers, pilihan);
  } else {
    print("Pilihan tidak valid");
  }

  stopwatch.stop();
  print("Waktu eksekusi: ${stopwatch.elapsedMicroseconds} microseconds");
}

void performOperation(List<int> numbers, int pilihan) {
  switch (pilihan) {
    case 1:
      print("Hasil Bubble Sort: ${bubbleSort(numbers)}");
      break;
    case 2:
      print("Hasil Inversi: ${countInversions(numbers)}");
      break;
    case 3:
      print("Hasil Shuffle: ${shuffle(numbers)}");
      break;
  }
}

// Fungsi Bubble Sort
List<int> bubbleSort(List<int> list) {
  int n = list.length;
  bool swapped;
  do {
    swapped = false;
    for (int i = 1; i < n; i++) {
      if (list[i - 1] > list[i]) {
        int temp = list[i - 1];
        list[i - 1] = list[i];
        list[i] = temp;
        swapped = true;
      }
    }
    n--;
  } while (swapped);
  return list;
}

// Fungsi Shuffle
List<int> shuffle(List<int> list) {
  Random random = Random();
  for (int i = list.length - 1; i > 0; i--) {
    int j = random.nextInt(i + 1);
    int temp = list[i];
    list[i] = list[j];
    list[j] = temp;
  }
  return list;
}

// Fungsi Inversi
List<int> countInversions(List<int> list) {
  int left = 0;                
  int right = list.length - 1;

  while (left < right) { 
    int temp = list[left];
    list[left] = list[right];
    list[right] = temp;

    left++; 
    right--; 
  }

  return list; 
}
